# Rice-Disease-DataSet

This is the dataset used by me and my thesis mates when we created a Image Recognition application. they are sorted by diseases and labeled using Labelimg.exe

---
we covered the following diseases for rice plants:
* Bacterial Leaf Blight ( BLB )
* Blast
* Brown spot

---
The datasets provided here are of optimium age (3 to 4 weeks). this is because a disease that is too old or too young cannot be accurately detected. it would need additional data to do so (weather,water sample,leaf sample tests,etc)
